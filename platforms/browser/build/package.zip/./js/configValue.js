	angular.module("eurecaJovem").value("config", {
	    //webServiceURL: "http://anga-eureca.jelasticlw.com.br/ws"
	    webServiceURL: "http://localhost:8080/eureca/ws",
	    imageServiceURL: "http://localhost:8080/eureca/imagem"
	});
